<?php 
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpwd = "";
    $dbname = "absensi_pkl";

    $conn = new mysqli($dbhost, $dbuser, $dbpwd, $dbname);
 ?>
