# Absensi_siswa_PKL
Tutorial pemasangan baca di : codinger-mini.blogspot.com
Jejak : fb.me/rizal.ofdraw
